package com.koreait.jpaitem.relration;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

//@Entity
@Getter @Setter
public class Member {	//연관관계 매핑 예제(class - Member, Team) 1.

	@Id	@GeneratedValue
	@Column(name = "MEMBER_ID")
	private Long id;
	
	@Column(name = "USERNAME")
	private String name;

	// fk 키 설정 전
//	@Column(name = "TEAM_ID")
//	private Long teamid;
	
	// fk 키 설정 함	-> Team에 @OneToMany 까지 작성해야 완성
	// @ManyToOne : 많은 것중 하나, 여기에선 Team이 하나
	// @JoinColumn(name = "TEAM_ID") : 관계 컬럼을 적어준다. TEAM_ID와 조인해야 한다. name 값이 있으면 name값으로 없으면 그냥 값 사용
	// 외래키가 있는 객체가 주인(즉, Member 클래스가 주인)
	@ManyToOne
	@JoinColumn(name = "TEAM_ID")
	@Setter(value = AccessLevel.NONE)	// lombok에서 자동 setter 생성을 막아준다. 
	private Team team;

	// 일반적으로 setter의 형태가 아니면 메서드 이름을 바꿔준다.
	// 추후 소스코드를 봤을때 단순 setter의 작업이 아닌 중요한 작업을 진행하는지를 파악 할 수 있다.
	public void changeTeam(Team team) {		// 원래 setTeam이였는데 이름 변경해줌 
		this.team = team;
		// this : 나 자신의 인스턴스를 넣어준다.
		team.getMember().add(this);		//JpaMain2에 team.getMember().add(member);와 같은 역할이다.
	}

	public void setTeam(Team team) { // team.java에 위처럼 changeTeam을 만들어 주기위해
		this.team = team;
	}

	// lombok -> @ToString 으로 member나 team에서 다 만들어 버리면 무한 루프가 되버릴수 있어 사용 조심
	@Override
	public String toString() {
		return "Member [id=" + id + ", name=" + name + ", team=" + team + "]";
	}
	
	
	
	
	
	
	
	
	
}
