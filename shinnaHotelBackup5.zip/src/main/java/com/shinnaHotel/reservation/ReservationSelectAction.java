package com.shinnaHotel.reservation;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shinnaHotel.DAO.ReservationDAO;
import com.shinnaHotel.action.Action;
import com.shinnaHotel.action.ActionForward;

public class ReservationSelectAction implements Action{
	// 예약된 내역 조회
	
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) {
		ActionForward forward = new ActionForward();
		ReservationDAO rdao = new ReservationDAO();
		
		HttpSession session = req.getSession();		
		String u_id = (String)session.getAttribute("u_id");
		
		req.setAttribute("reservationlist", rdao.selectReservation(u_id));

		forward.setRedirect(false);
		forward.setPath("reservationlist.jsp");
		
		return forward;
	}
		
		
		// 페이지 수 테스트
		
//		// 전체 개수
//		int totalCnt = rdao.getReservationCnt();
//				
//		// 페이징 처리  - 시작
//		// 현재 넘겨받은 페이지
//		String temp = req.getParameter("page");
//		int page = 0;
//		
//		page = temp == null ? 1 : Integer.parseInt(temp); // 상항연산자로 if문 쉽게 해봄
//		
//		//페이지 처리 [1][2]....[10] : 10개씩
//		int pageSize = 10;
//		
//		// 1페이지 endRow = 10, 4페이지 endRow = 40
//		int endRow = page * 10;
//		
//		// 1페이지의 startRow = 1, 4페이지의 startRow = 31
//		int startRow = endRow - 9;
//		
//		// [1], [2], ... [10] : [1], [11], [12], ..., [20] : [11]
//		int startPage = (page-1) / pageSize * pageSize + 1;
//		
//		// [1], [2], ... [10] : [10], [11], [12], ..., [20] : [20]
//		int endPage = startPage + pageSize - 1;
//		
//		int totalPage = (totalCnt - 1) / pageSize + 1;
//		
//		endPage = endPage > totalPage? totalPage : endPage;
//		
//		req.setAttribute("totalPage", totalPage);
//		req.setAttribute("nowPage", page);
//		req.setAttribute("startPage", startPage);
//		req.setAttribute("endPage", endPage);
//		
//		
//		req.setAttribute("ReservationList", rdao.getReservationList(startRow, endRow)); 
//		req.setAttribute("totalCnt", totalCnt);
		
		// 페이지 수 테스트
	
		
		
	 
}
