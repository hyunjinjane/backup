package com.shinnaHotel.reservation;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shinnaHotel.DAO.ReservationDAO;
import com.shinnaHotel.action.Action;
import com.shinnaHotel.action.ActionForward;

public class ReservationCancelAction implements Action{
	// 예약 취소하기
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) {
		ActionForward forward = new ActionForward();
		
		ReservationDAO rdao = new ReservationDAO();
		
		int res_number = Integer.parseInt(req.getParameter("res_number"));
		
		// 취소 하기 클릭 시 취소 테이블에 insert 후 예약 테이블 delete
		
		// 인서트
//		rdao.insertCancel();
		
//		if(rdao.res_delete(res_number)) {
//			forward.setRedirect(false);
//			forward.setPath(req.getContextPath() + );
//		}
		
		return forward;
	}
	 
}
