package com.koreait.querydsl.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter @Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@ToString(of = {"id", "username", "age"})
public class Member {	// 2.	-> Mian.java
	
	@Id @GeneratedValue
	@Column(name = "member_id")
	private Long id;
	
	private String username;
	private int age;
	
	@ManyToOne
	@JoinColumn(name = "team_id")
	private Team team;
	

	public Member(String username) {
		this(username, 0);
	}	// 아래쪽 this에 넣어줄것
	
	public Member(String username, int age) {
		this(username, age, null);
	}	// 아래쪽 this에 넣어줄것
	
	public Member(String username, int age, Team team) {
		super();
		this.username = username;
		this.age = age;
		if(team != null) {
			changeTeam(team);
		}
		
		this.team = team;
	}
	
	public void changeTeam(Team team) {
		this.team = team;
		//getter
		team.getMembers().add(this);
	}

	
	// Lombok에서 대신 처리가 가능하다
	// @NoArgsConstructor(access = AccessLevel.PROTECTED)
//	protected Member() {}
	
	// toString	- team까지 넣으면 무한루프 돌기 때문에 빼줘야 한다
	// lombok 에서 대신 처리 가능	- 필요할것만(tea빼고) 설정해주기
//	@Override
//	public String toString() {
//		return "Member [id=" + id 
//				+ ", username=" + username 
//				+ ", age=" + age + "]";
//	}
	
	
	

}
