package com.koreait.querydsl.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.koreait.querydsl.entity.Member;
import static com.koreait.querydsl.entity.QMember.*;	
import static com.koreait.querydsl.entity.QTeam.*;		// 추가
import com.koreait.querydsl.entity.Team;
import com.querydsl.core.Tuple;
import com.querydsl.jpa.impl.JPAQueryFactory;

public class Main6 {		// 8.	(Member.java, Team.java 만들어 줌)
	public static void main(String[] args) {
		JPAQueryFactory queryFactory;
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");			
		EntityManager em = emf.createEntityManager();		
		EntityTransaction tx = em.getTransaction();
		queryFactory = new JPAQueryFactory(em);
		tx.begin(); 	
		
		try {
			
			Team teamA = new Team("teamA");
			Team teamB = new Team("teamB");
			em.persist(teamA);
			em.persist(teamB);
			
			Member member1 = new Member("member1", 10, teamA);
			Member member2 = new Member("member2", 20, teamA);
			Member member3 = new Member("member3", 30, teamB);
			Member member4 = new Member("member4", 40, teamB);
			Member member5 = new Member(null, 100, teamB);
			Member member6 = new Member("member6", 100, teamB);
			Member member7 = new Member("member7", 100, teamB);
			em.persist(member1);
			em.persist(member2);
			em.persist(member3);
			em.persist(member4);
			em.persist(member5);
			em.persist(member6);
			em.persist(member7);
			
			// 최기화
			em.flush();
			em.clear();
		
			
			List<Member> result = queryFactory
									.selectFrom(member)
									// member에 있는 team과 team을 조인
									.join(member.team, team)			// inner조인을 기본으로 가지고온다
									.fetch();
			
			System.out.println(result.toString());
			
			
			// 세타 조인
			/*
			 * 세타 조인
			 * 	- 연관관계가 없는 필드로 조인
			 * 	- 회원의 이름이 팀 이름과 같은 회원 조회(연관관계가 없는 필드이지만(좀 엉뚱한) 데이터를 가지고 와야할때)
			 * 
			 */
			
			em.persist(new Member("teamA"));
			em.persist(new Member("teamB"));
			
			List<Member> result2 = queryFactory
										.select(member)
										.from(member, team)		// 연관관계가 없으니까 각가에 entity를 가지고온것 -> cross조인으로 모든 데이터를 다 가지고 와서 조건(where)로 걸러지는것
										.where(member.username.eq(team.name))
										.fetch();
			
			System.out.println(result2.toString());
										
			
			/*
			 * 회원과 팀을 조인하면서, 팀 이름이 teamA인 팀만 조인, 회원은 모두 조회
			 * SQL : 	select 	m.*, t.*
			 * 			from	member m
			 * 					left outer join Team t 
			 * 						on m.team_id = t.team_id and t.name = 'teamA'
			 */
			
//			List<Tuple> result3 = queryFactory
//									.select(member, team)
//									.from(member)
//									.leftJoin(member.team, team).on(team.name.eq("teamA"))		// leftjoin
//									.fetch();
			
			List<Tuple> result3 = queryFactory
									.select(member, team)
									.from(member)
									.join(member.team, team).on(team.name.eq("teamA"))			// join
									.fetch();
			
			for(Tuple tuple : result3) {
				System.out.println("tuple : " + tuple);
			}
			
			
			
			
			
			tx.commit();
		}catch(Exception e) {
			tx.rollback();
		}finally {
			em.close();
			emf.close();
		}
		
		
	}
}
