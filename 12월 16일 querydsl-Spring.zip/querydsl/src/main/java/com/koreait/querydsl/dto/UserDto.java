package com.koreait.querydsl.dto;

import lombok.Data;

@Data
public class UserDto {	//	13.
	
	private String name;
	private int age;

}
