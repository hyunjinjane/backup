package com.koreait.querydsl.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.koreait.querydsl.entity.Member;
import static com.koreait.querydsl.entity.QMember.*;	// QMember클래스 자체를 static 영역에 올리고싶을때 사용
import com.koreait.querydsl.entity.Team;
import com.querydsl.jpa.impl.JPAQueryFactory;

public class Main {		// 1.	(Member.java, Team.java 만들어 줌)
	public static void main(String[] args) {
		JPAQueryFactory queryFactory;
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");			
		EntityManager em = emf.createEntityManager();		
		EntityTransaction tx = em.getTransaction();
		queryFactory = new JPAQueryFactory(em);
		tx.begin(); 	
		
		try {
			
			Team teamA = new Team("teamA");
			Team teamB = new Team("teamB");
			em.persist(teamA);
			em.persist(teamB);
			
			Member member1 = new Member("member1", 10, teamA);
			Member member2 = new Member("member2", 20, teamA);
			Member member3 = new Member("member3", 30, teamB);
			Member member4 = new Member("member4", 40, teamB);
			em.persist(member1);
			em.persist(member2);
			em.persist(member3);
			em.persist(member4);
			
			// 최기화
			em.flush();
			em.clear();
		
			
			// jpql - 셀렉트문
			// member1 찾기
			String qString  = "select m from Member m where m.username = :username";
			Member findByJpql = em.createQuery(qString, Member.class)
									.setParameter("username", "member1")
									.getSingleResult();
			
			System.out.println("findByJpql : " + findByJpql.getUsername().equals("member1"));
			
			
			// queryDSL	- 셀렉트문 QClass 사용
			//QMember m = new QMember("m");	// QMember의 이름 부여, 별칭 부여(QMember에 m이라는 알리야스를 만들어 준것)
			//QMember m = QMember.member;		// QMember에서 기본적으로 설정된걸 사용하는 것
			
//			Member findByQueryDSL = queryFactory.select(m)	
//												.from(m)
//												.where(m.username.eq("member1"))		// 파라미터 바인딩
//												.fetchOne();
			
			Member findByQueryDSL = queryFactory.select(member)		// import 를 해줘야함
												.from(member)
												.where(member.username.eq("member1")
														.and(member.age.eq(10)))		// 파라미터 바인딩
												.fetchOne();
			
	//		System.out.println("findByQueryDSL : " + findByQueryDSL.getUsername().equals("member1"));
			System.out.println("findByQueryDSL : " + findByQueryDSL.toString());
			
			
			Member findQueryDSL2 = queryFactory.selectFrom(member)
												. where(member.username.eq("member1").and(member.age.between(10, 30)))
												.fetchOne();
			
			
			Member findQueryDSL3 = queryFactory.selectFrom(member)
												. where(
														member.username.eq("member1"),
														member.age.between(10, 30)
												)
												.fetchOne();

			
			
			
			
			tx.commit();
		}catch(Exception e) {
			tx.rollback();
		}finally {
			em.close();
			emf.close();
		}
		
		
	}
}
