package com.koreait.querydsl.dto;

import lombok.Data;

@Data
public class MemberDto {	// 12.
	
	private String username;
	private int age;
	
	public MemberDto(String username, int age) {
		super();
		this.username = username;
		this.age = age;
	}
	
	
	public MemberDto() {} // 기본생성자
	
	

}
