package com.koreait.jpashop.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.koreait.jpashop.domain.Item;
import com.koreait.jpashop.domain.Member;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class ItemRepository {	// 12.

	private final EntityManager em;
	
	// 1. 상품 저장
	public void save(Item item) {
		// 처음에 item이 id가 없으면 신규등록
//		if (item.getId() == null) {
			
			// 1-1. 상품 신규 저장
			em.persist(item);
			
//		}else {
//			
//			// 1.2. jpa를 통해서 db에 한번 들어간 값 (수정 - update)   
//			em.merge(item);			<- merge 사용 비추천
//			
//		}
		
	}
	
	
	
	
	// 2. 여러건 조회
	public List<Item> findAll(){
		return em.createQuery("select i from Item i", Item.class).getResultList();
	}
	
	
	// 3. 상품 1건 조회
	public Item findOne(Long id) {
		return em.find(Item.class, id);
	}
	
	
	
	
	
}
