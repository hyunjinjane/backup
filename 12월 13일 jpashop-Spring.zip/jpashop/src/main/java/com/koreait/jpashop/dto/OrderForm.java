package com.koreait.jpashop.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class OrderForm {	// 18.

	private Long id;
	private int count;		
	
	
	
	
	
}
