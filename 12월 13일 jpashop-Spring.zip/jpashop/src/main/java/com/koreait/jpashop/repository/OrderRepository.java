package com.koreait.jpashop.repository;

import org.springframework.stereotype.Repository;

@Repository
public class OrderRepository {		// 17.

}
