package com.koreait.jpashop.dto;

import javax.validation.constraints.NotEmpty;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class MemberForm {	// 7. -> MemberController.java에 써줌(빈값으로 넣어줌)

	@NotEmpty(message = "회원 이름은 필수입니다.")
	private String name;
	private String city;
	private String street;
	private String zipcode;
	
	
}
