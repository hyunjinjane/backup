package com.koreait.mylogin.loginweb.login;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.koreait.mylogin.loginweb.member.Member;
import com.koreait.mylogin.loginweb.session.SessionConst;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class LoginController {
	
	private final LoginService loginService;

	@GetMapping("/login")
	public String loginForm(@ModelAttribute("loginForm")LoginForm loginForm) {
		return "login/loginForm";
	}

	//day08===

		
//	@PostMapping("/login")			
	public String login(@ModelAttribute LoginForm form, Model model, 
			RedirectAttributes redirectAttributes, HttpServletResponse response) {		// 쿠키로 로그인 유지를 하기위해 쿠키를 사용해 봄 (HttpServletResponse 사용해서)
		
		Member loginMember = loginService.login(form.getLoginId(), form.getPassword());
		if( loginMember == null ) {
			// 로그인 실패
			model.addAttribute("msg", "로그인실패");
			return "login/loginForm";
		} 

		/*
		 *  - addAttribute 		: url 뒤에 붙는다.(계속 가지고 가려면 이거 사용)
		 *  - addFlashAttribute : url 뒤에 붙지 않는다. (1회성이 있다)
		 */
		// 로그인 성공
		Cookie idCookie = new Cookie("memberId", String.valueOf(loginMember.getId()));	// 쿠키로 로그인 유지해 보기
		response.addCookie(idCookie);													// 다음은 HomeController 수정해줌 homev2
		
		redirectAttributes.addFlashAttribute("msg", "로그인 성공");
		return "redirect:/";
	}
	
	
//	@PostMapping("/login")			
	public String loginv2(@ModelAttribute LoginForm form, Model model, 
			RedirectAttributes redirectAttributes, HttpServletRequest request) {		// session로 로그인 유지를 하기위해 세션를 사용해 봄 (HttpServletRequest request 사용해서)
		
		Member loginMember = loginService.login(form.getLoginId(), form.getPassword());
		if( loginMember == null ) {
			// 로그인 실패
			model.addAttribute("msg", "로그인실패");
			return "login/loginForm";
		} 

		// 로그인 성공
		HttpSession session = request.getSession();
		// 세션에 로그인 회원 정보 보관
		session.setAttribute(SessionConst.LOGIN_MEMBER, loginMember);

		redirectAttributes.addFlashAttribute("msg", "로그인 성공");
		return "redirect:/";
	}
	

	@PostMapping("/login")
	public String loginV3(@ModelAttribute LoginForm form , Model model,
			RedirectAttributes redirectAttributes, HttpServletRequest request,
			@RequestParam(defaultValue = "/")String redirectURL) { //파라미터 값을 redirectURL 로 가져올 건데 없으면 디폴트인 /로..(2:2)
		
		// 아이디와 패스워드 모두 검증해줘야함 -> 검증은 서비스에서
		// 있으면 loginMember 객체에 값 담기고 없으면 null이 담길 거다
		// loginMember 에는 member값 또는 null값이 들어있다
		Member loginMember = loginService.login(form.getLoginId(), form.getPassword());
		
		if(loginMember == null) {
			//로그인 실패 - LoginForm.html <script>
			model.addAttribute("msg", "로그인 실패");
			return "login/loginForm";
		}
		
		//로그인 성공
		HttpSession session = request.getSession();
		//세션에 로그인 회원 정보 보관
		session.setAttribute(SessionConst.LOGIN_MEMBER, loginMember);
		
		redirectAttributes.addFlashAttribute("msg", "로그인 성공");
		return "redirect:" + redirectURL; //내가 가고자하는 경로로 보내줌(바로 홈화면으로 보내주는 것이 아니라)
		
	}

	//=======================================================	
		
//	@PostMapping("/logout")
	public String logout(HttpServletResponse response) {	//로그아웃하면 id를 null 처리 해줌 <- cookie
		Cookie cookie = new Cookie("memberId", null);
		cookie.setMaxAge(0);
		response.addCookie(cookie);
		
		return "redirect:/";
	}
	
	
	@PostMapping("/logout")
	public String logoutv2(HttpServletRequest request) {	//로그아웃하면 id를 삭제 해줌	<- session
		// 세션을 삭제
		/*
		 * request.getSession(true)
		 * 	- 세션이 있으면 기존 세션을 반환한다.
		 * 	- 세션이 없으면 새로운 세션을 생성해서 반환한다.
		 * 
		 * request.getSession(false)
		 * 	- 세션이 있으면 기존 세션을 반환한다.
		 * 	- 세션이 없으면 새로운 세션을 생성하지 않고, null을 반환
		 */
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}
		
		return "redirect:/";			// -> 다음은 HomeController 바꿔줌 homev3 -> homev4
	}
	

	

}
