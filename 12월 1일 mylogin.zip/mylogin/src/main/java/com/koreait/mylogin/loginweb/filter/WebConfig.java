package com.koreait.mylogin.loginweb.filter;

import javax.servlet.Filter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.koreait.mylogin.loginweb.interceptor.LogInterceptor;
import com.koreait.mylogin.loginweb.interceptor.LoginCheckInterceptor;

@Component
public class WebConfig implements WebMvcConfigurer{	// 필터 등록만 함	-> LoginCheckFilter 클래스 만들어서 login했을때나 그럴때 적용해주기 (Spring에는 인터셉터라는게 filter대신 사용할수 있음)

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new LogInterceptor())
				.order(1)
				.addPathPatterns("/**")
				.excludePathPatterns("/error");
		
		registry.addInterceptor(new LoginCheckInterceptor())
		.order(2)
		.addPathPatterns("/**")				// 모든 경로 전체
		.excludePathPatterns("/", "/members/add", "/login", "/logout", "/css/**");
	}
	
//	@Bean
	public FilterRegistrationBean logFilter() {
		FilterRegistrationBean<Filter> filterRegistrationBean = new FilterRegistrationBean<Filter>();
		
		filterRegistrationBean.setFilter(new LogFilter());	// LogFilter 등록
		filterRegistrationBean.setOrder(1);		// 1번으로 등록해줘
		filterRegistrationBean.addUrlPatterns("/*"); 		// 모든 url 다 적용
		return filterRegistrationBean;
		
	}
	
//	@Bean
	public FilterRegistrationBean loginCheckFilter() {
		FilterRegistrationBean<Filter> filterRegistrationBean = new FilterRegistrationBean<Filter>();
		
		filterRegistrationBean.setFilter(new LoginCheckFilter());	// LoginCheckFilter 등록
		filterRegistrationBean.setOrder(2);		// 1번으로 등록해줘
		filterRegistrationBean.addUrlPatterns("/*"); 				// 모든 url 다 적용
		return filterRegistrationBean;
		
	}
	
	
	
	
	
	
	
	
	
}
