package com.koreait.mylogin.loginweb.session;

public class SessionConst {		// session의 키 값을 만들어 놓으려고 만든 클래스
	
	public static final String LOGIN_MEMBER = "loginMember";
	
	

}
