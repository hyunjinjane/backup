package com.koreait.mylogin.loginweb.filter;

import java.io.IOException;
import java.net.http.HttpResponse;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.util.PatternMatchUtils;

import com.koreait.mylogin.loginweb.session.SessionConst;

public class LoginCheckFilter implements Filter{
	
	 //이 경로를 제외한 나머지 경로를 다 login 체크
	private static final String[] whitelist = {"/", "/members/add", "/login", "/logout"};

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest)request;
		String requestURI = httpRequest.getRequestURI();
		HttpServletResponse httpResponse = (HttpServletResponse)response;
		
		System.out.println("인증 체크 필터 시작" );
		if(isLoginCheckpath(requestURI)) { //whitelist에 있는 uri는 검증하지 않을 거야 - requestURI를 기점으로 whitelist와 비교를 하면 된다. // requestURI이 whitelist에 있느냐 없느냐
			System.out.println("인증 체크 로직 실행 : " + requestURI); //if문을 탔다면 인증 체크 로직 실행
			//해당 요청에 session 값 담겨있는지
			HttpSession session = httpRequest.getSession(false);
			if(session == null 
					|| session.getAttribute(SessionConst.LOGIN_MEMBER) == null) {// null = 로그인한 적 없는 사용자의 요청
				System.out.println("미 인증 사용자 요청");
				// 로그인으로 redirect
				httpResponse.sendRedirect("/login?redirectURL=" + requestURI); //1:58
				
				//필터에서 이러한 요청이 넘어왔다 -> 그럼 다음 단계로 진행되면 안 되기 때문에 끝내줄 거임
				// 미인증 사용자는 다음으로 진행하지 않고 끝낸다.
				return;
			}
		}
		
		// 위의 if 문 조건 안 탔으면 다음단계로 넘어간다.
		chain.doFilter(request, response);
	} 
	
	/*
	 * 화이트 리스트의 경우 인증 체크 x
	 * simpleMatch : 파라미터 문자열이 특정 패턴에 매칭되는지를 검사함
	 */
	private boolean isLoginCheckpath(String requestURI) {	
		//스프링에서 제공해주는 클래스, 반복문 돌아서 체크해도 전혀 상관 없는데, 이 클래스를 사용 1:39
		return !PatternMatchUtils.simpleMatch(whitelist, requestURI) ;//매칭이 되면 TRUE, 매칭이 안 될 때 인증체크 태울 거라 부정 붙임
		//PatternMatchUtils, simpleMatch 공부
		//whitelist : 대상 , requestURI : 비교할 대상
	}
	// WebConfig에 적용해줘야함 loginCheckFilter 만들어 줌








}

