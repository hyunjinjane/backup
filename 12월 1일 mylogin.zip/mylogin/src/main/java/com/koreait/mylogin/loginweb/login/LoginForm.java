package com.koreait.mylogin.loginweb.login;

import lombok.Data;

@Data
public class LoginForm {
	private String loginId;
	private String password;

}
