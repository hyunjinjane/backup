package com.koreait.jpaitem.relration;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
public class Member {	//연관관계 매핑 예제(class - Member, Team) 1.

	@Id	@GeneratedValue
	@Column(name = "MEMBER_ID")
	private Long id;
	
	@Column(name = "USERNAME")
	private String name;

	// fk 키 설정 전
//	@Column(name = "TEAM_ID")
//	private Long teamid;
	
	// fk 키 설정 함
	// @ManyToOne : 많은 것중 하나, 여기에선 Team이 하나
	// @JoinColumn(name = "TEAM_ID") : 관계 컬럼을 적어준다. TEAM_ID와 조인해야 한다. name 값이 있으면 name값으로 없으면 그냥 값 사용
	@ManyToOne
	@JoinColumn(name = "TEAM_ID")	
	private Team team;
	
	
}
