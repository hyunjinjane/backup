package com.koreait.jpaitem.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

//@Entity
@Getter @Setter
public class Item {	// 1.

	@Id @GeneratedValue
	@Column(name = "ITEM_ID")
	private Long Id;
	private String name;
	private int price;
	private int stockQeantity;
	
}
