package com.koreait.jpaitem;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.koreait.jpaitem.relration.Member;
import com.koreait.jpaitem.relration.Team;

public class JpaMain {
	public static void main(String[] args) {	// 5.
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		try {
			
//			//연관관계 매핑 예제(class - Member, Team) 3.	
//			Team team = new Team();
//			team.setName("TeamA");
//			// 영속상태가 되면, PK의 값이 세팅이 된 후 영속상태 된다.
//			em.persist(team);
//			
//			Member member = new Member();
//			member.setName("member1");
//			member.setTeamid(team.getId()); // 1.에서 fk 키 설정 전
//			em.persist(member);
//			
//			// select
//			// 어느팀 소속인지 알고 싶을 때 jpa or db 에게 계속 물어봐야 한다.
//			Member findMember = em.find(Member.class, member.getId());		// 한 row만 조회됨	, 찾고자 하는 멤버의 팀의 이름 찾기
//			Long findTeamid = findMember.getTeamid();
//			Team findTeam = em.find(Team.class, findTeamid);
//			System.out.println("findTeam : " + findTeam.getName());			// 팀이름 출력		findTeam : TeamA
			
		
			Team team = new Team();
			team.setName("TeamA");
			// 영속상태가 되면, PK의 값이 세팅이 된 후 영속상태 된다.
			em.persist(team);
			
			Member member = new Member();
			member.setName("member1");
			member.setTeam(team);  			// 1.에서 fk 키 설정 후
			em.persist(member);
			
			// 강제로 db 쿼리를 보고 싶을때 (1차캐시에서 가지고 오니 select문이 없는데 그래도 보고싶을때 이 두개 추가)
			em.flush();
			em.clear();
			
			// select
			// find시에 1차캐시에서 가지고 와서 select 문이 없다. 
			Member findMember = em.find(Member.class, member.getId());		
			Team findTeam = findMember.getTeam();
			System.out.println("findTeam : " + findTeam.getName());			// 팀이름 출력		findTeam : TeamA
			
			
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
		}finally {
			em.close();
			emf.close();
		}
		
		
		
		
		
		
		
		
		
		
	}

}
