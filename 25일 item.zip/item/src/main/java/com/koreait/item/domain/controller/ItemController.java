package com.koreait.item.domain.controller;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.koreait.item.domain.item.Item;
import com.koreait.item.domain.item.ItemRepository;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/basic/items")
@RequiredArgsConstructor		
// @RequiredArgsConstructor	: final 이 붙은 멤버변수만 사용해서 생성자를 자동으로 만들어준다.  // 생성자도 생략가능 롬북이 대신해준다
public class ItemController {
	
	private final ItemRepository itemRepository;
	
//	@Autowired
	// 생성자가 1개만 있으면 @Autowired 생략가능
//	public ItemController(ItemRepository itemRepository) {
//		this.itemRepository = itemRepository;
//	}
	
	@GetMapping
	public String items(Model model) {
		List<Item> items = itemRepository.findAll();
		model.addAttribute("items", items);
		return "basic/items";
	}
	
	
	// /basic/items/아이템의ID
	@GetMapping("/{itemId}")
	public String item(@PathVariable Long itemId, Model model) {
		Item item = itemRepository.findById(itemId);
		model.addAttribute("item", item);
		return "basic/item";
	}
	
	
	@GetMapping("/add")
	public String addForm() {
		return "basic/addForm";
	}
	
	//등록하기
//	@PostMapping("/add")
	public String save(@RequestParam String itemName,
					   @RequestParam int price,
					   @RequestParam Integer quantity,
					   Model model) {
		Item item = new Item();
		item.setItemName(itemName);
		item.setPrice(quantity);
		item.setQuantity(quantity);
		
		itemRepository.save(item);
		
		model.addAttribute("item", item);
		return "basic/item"; //등록이 완료된 상세페이지 보여줌
	}
	
	
//	@PostMapping("/add")
	public String saveV2(@ModelAttribute("item")Item item) {
		// @ModelAttribute 가 해주는 역할
//		Item item = new Item();
//		item.setItemName(itemName);
//		item.setPrice(quantity);
//		item.setQuantity(quantity);
		
		itemRepository.save(item);
		
//		model.addAttribute("item", item);
		return "basic/item"; 
	}

	/*
	 * ModelAttribute 에서 name 생략
	 * 	-> 생략시 model에 저장되는 name은 클래스명 첫 글자만 소문자로 등록
	 * 		Item -> item
	 */
//	@PostMapping("/add")
	public String saveV3(@ModelAttribute Item item) {		
		itemRepository.save(item);		
		return "basic/item"; 
	}
	
	/*
	 * @ModelQttribute 자체도 생략 가능, 그러나 가독성을 위해 권잘하지 않음
	 */
//	@PostMapping("/add")
	public String saveV4(Item item) {	//<- 어노테이션 생략까지는 잘 하지 않음
		itemRepository.save(item);		
		return "basic/item"; 
	}
	
//	@PostMapping("/add")
	public String saveV5(Item item) {	
		itemRepository.save(item);		
		return "redirect:/basic/items/" + item.getId(); //<- redirect 버전 새로고침을 해도 그대로 남아있기때문데 새로 생기지 않음
	}
	
	/*
	 * "redirect:/basic/items/{itemId}"
	 *  ->@PathVariable	과 mapping이 되는 부분은 : {itemId}
	 *  -> 나머지는 파라미터로 처리	: ?status = true
	 */
	@PostMapping("/add")
	public String saveV6(Item item, RedirectAttributes redirectAttributes) {	
		Item saveItem = itemRepository.save(item);	
		
		redirectAttributes.addAttribute("itemId", saveItem.getId()); 	//redirect 속성값을 저장했음
		redirectAttributes.addAttribute("status", true);				// mapping이 안되는 건 이게 파라미터로 다 담어서 보내줌
		
		return "redirect:/basic/items/{itemId}"; 
	}

	
	// 수정하기 페이지 이동
	@GetMapping("/{itemId}/edit")
	public String editForm(@PathVariable Long itemId, Model model) {
		Item item = itemRepository.findById(itemId);
		model.addAttribute("item", item);
		return "basic/editForm";
	}
	
	// 수정하기 내용 업데이트 후 상세페이지 이동
	@PostMapping("/{itemId}/edit")
	public String edit(@PathVariable Long itemId, @ModelAttribute Item item) {
		itemRepository.update(itemId, item);
		// 상세페이지 이동
		return "redirect:/basic/items/{itemId}";	// /basic/items/아이템의ID 이쪽으로 mapping이 됨
		
	}
	
	
	
	
	
	
	
	// 테스트용 데이터 추가
	@PostConstruct
	public void init() {
//		System.out.println("최기화 메서드");
		itemRepository.save(new Item("testA", 10000, 10));
		itemRepository.save(new Item("testB", 20000, 20));
	}
	
	// 종료 메서드
	@PreDestroy
	public void destroy() {
		System.out.println("종료 메서드");
	}
	
	
	
	
	
	
	
}
