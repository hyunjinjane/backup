package com.koreait.item.enumeration;

public enum Week {	//Main01
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;
	
	
	public void dayInfo() {
		System.out.println("dayInfo enum");
	}
	
	
}
