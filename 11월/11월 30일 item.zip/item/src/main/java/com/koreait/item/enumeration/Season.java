package com.koreait.item.enumeration;

public enum Season {	// Main02
	SPRING, SUMMER, FALL, WINTER
}
