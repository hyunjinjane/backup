package com.shinnaHotel.reservation;

public class ReservationCheckAction {

}
