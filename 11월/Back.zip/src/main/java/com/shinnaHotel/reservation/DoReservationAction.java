package com.shinnaHotel.reservation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shinnaHotel.DAO.ReservationDAO;
import com.shinnaHotel.DTO.ReservationDTO;
import com.shinnaHotel.action.Action;
import com.shinnaHotel.action.ActionForward;

public class DoReservationAction implements Action{
	// 예약하기
	
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) {
		System.out.println("execute 도착");
		
		ActionForward forward = new ActionForward();
		ReservationDAO rdao = new ReservationDAO();
		ReservationDTO rdto = new ReservationDTO();
		
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date res_checkin = null;
		Date res_checkout = null;
		
		try {
			res_checkin = transFormat.parse(req.getParameter("checkin_date"));
			res_checkout = transFormat.parse(req.getParameter("checkout_date"));
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int res_adults = Integer.parseInt(req.getParameter("adults"));
		int res_kids = Integer.parseInt(req.getParameter("children"));
		String r_type = req.getParameter("r_type");
		int r_price = Integer.parseInt(req.getParameter("r_price"));
		
		
		rdto.setRes_checkin(res_checkin);
		rdto.setRes_checkout(res_checkout);
		rdto.setRes_adults(res_adults);
		rdto.setRes_kids(res_kids);
		rdto.setRes_rtype(r_type);
		rdto.setRes_price(r_price);
		
		forward.setRedirect(false);
			
		forward.setPath("/reservation/reservationList.re");
		
		
		return forward;
	}
	 
}
