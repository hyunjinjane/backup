package com.koreait.thymeleaf.bean;

import org.springframework.stereotype.Component;

@Component("helloBean")			// @Component("이름")을 사용해서 Bean을 만들어줌, 
								// spring 컨테이너 안에 아무 역할을 하지는 않지만 필요에 따라 객체 생성해서 넣어줄수 있음
public class HelloBean {

	public String hello(String data) {
		return "Hello" + data;
	}
	
	
}
