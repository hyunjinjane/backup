package com.koreait.mylogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyloginApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyloginApplication.class, args);
	}

}
