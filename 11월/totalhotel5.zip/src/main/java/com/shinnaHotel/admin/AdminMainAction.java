package com.shinnaHotel.admin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shinnaHotel.DAO.AdminDAO;
import com.shinnaHotel.action.Action;
import com.shinnaHotel.action.ActionForward;

public class AdminMainAction implements Action{

	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) {
		ActionForward forward = new ActionForward();
		AdminDAO adao = new AdminDAO();
		
		String u_id = (String)req.getAttribute("u_id");		
		
		req.setAttribute("adminList", adao.getAdminList());
		req.setAttribute("adminReserveList", adao.getAdminReserveList(u_id));

		
		System.out.println("액션도착");
		forward.setRedirect(false);
		forward.setPath("/admin/admin.jsp" );
		return forward;
	}

}
