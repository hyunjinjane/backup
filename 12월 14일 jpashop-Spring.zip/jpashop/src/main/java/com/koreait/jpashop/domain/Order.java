package com.koreait.jpashop.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
@Table(name = "orders")
public class Order {	// 3.

	@Id @GeneratedValue
	@Column(name = "order_id")
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "member_id")
	private Member member;
	
	private LocalDateTime orderDate;
	
	@OneToMany(mappedBy = "order", cascade = CascadeType.ALL)		// CascadeType.All	옵션 추가 해줌(OrderItem 테이블에도 값을 넣기 위해)
	private List<OrderItem> orderItems = new ArrayList<OrderItem>();
	
	
	// 주문상태(ORDER, CANCEL) -> Enum으로 처리 (OrderStatus.java)
	@Enumerated(EnumType.STRING)
	private OrderStatus orderStatus;
	
	/////////// 연관관계 메서드
	public void setMember(Member member) {
		this.member = member;
		member.getOrders().add(this);
	}
	
	public void addOrderItem(OrderItem orderItem) {
		orderItems.add(orderItem);
		orderItem.setOrder(this);
	}
	/////////// 연관관계 메서드
	
	
	// 1-1.주문submit -> 주문 생성
	// 비지니스 로직
	public static Order createOrder(Member member, OrderItem...orderItems) {	// 아이템을 몇개를 가져올지 몰라하는 의미로 ...을 사용 -> test>Main01.java에 예시
		Order order = new Order();
		order.setMember(member);				// 바로 위에 setMember메서드 사용
		
		for( OrderItem orderItem : orderItems) {
			order.addOrderItem(orderItem);		// 바로 위에 setOrderItem메서드 사용
		}
		
		order.setOrderStatus(OrderStatus.ORDER);
		order.setOrderDate(LocalDateTime.now());
		return order;
		
	}
	
	
	// 3. 주문 취소
	public void cancel() {
		this.setOrderStatus(orderStatus.CANCEL);
		for(OrderItem orderItem : orderItems) {
			orderItem.cancel();		//-> 실질적으로 cancel 해주는 데는 OrderItem.java(로 이동해서 cancel만들어주기)
		}
	}
	
	
	
	
	
	
	
}
