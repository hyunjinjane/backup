package com.koreait.jpashop.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.catalina.Store;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.classmate.MemberResolver;
import com.koreait.jpashop.domain.Member;
import com.koreait.jpashop.repository.MemberRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class MemberService {	// 9.
	
	//@Autowired  
	public final MemberRepository memberRepository;

	// 1. 회원가입 로직
	@Transactional	// springframework의 어노테이션 선택하기 (Transactional이 두개가 나오니까 주의!)
	public Long join(Member member) throws IllegalAccessException {
		// 중복회원 검증 로직 추가
		validateMemberCheck(member);	// 바로 아래 만들어줌
		memberRepository.save(member);
		return member.getId();
	}
	
	private void validateMemberCheck(Member member) throws IllegalAccessException {
		List<Member> findMembers = memberRepository.findByName(member.getName());
		
		if (!findMembers.isEmpty()) {	// 비어있지 않다면 이미 존재한 이름이다
			throw new IllegalAccessException("이미 존재하는 회원입니다.");
		}
	}
	
	
	
	
	
	// 2. 멤버 모두 찾기
	// findMembers
	/*
	 * @Transactional(readOnly = true)
	 * : 읽기 전용일땐 넣어주면 비용을 아낀다.
	 */
//	@Transactional(readOnly = true)			<- 필요 할때마다 넣어줘도 되고 또는 class 위쪽에 한번만 해줘도 된다. 하지만 회원가입 같은 경우 readOnly가 아니므로 @Transactional 넣어 줘야 한다. 
	public List<Member> findMembers(){
		return memberRepository.findAll();
	}
	
	
	// 회원 단건 조회
//	@Transactional(readOnly = true)
	public Member findOne(Long memberId) {
		return memberRepository.findOne(memberId);
	}
	
	
	
	
}
