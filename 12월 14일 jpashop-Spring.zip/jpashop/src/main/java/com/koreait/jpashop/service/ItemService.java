package com.koreait.jpashop.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.koreait.jpashop.domain.Item;
import com.koreait.jpashop.repository.ItemRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ItemService {	//	11.
	
	public final ItemRepository itemRepository;
	
	// 1. 상품등록 로직
	@Transactional
	public void saveItem(Item item) {
		itemRepository.save(item);
	}
	
	
	// 2. 상품 모두 찾기 로직
	public List<Item> findItems(){
		return itemRepository.findAll();
	}
	
	
	
	// 3. 상품 수정페이지 로직
	public Item findOne(Long itemId){
		return itemRepository.findOne(itemId);
	}
	
	
	// 3-1. 상품 수정하기
	@Transactional
	public void updateItem(Long itemid, String name, int price, int stockQuantity) {
		Item findItem = itemRepository.findOne(itemid);		// 중요!!-영속성 컨텍스트 다녀왔다(영속성 컨텍스트에 속하기 위해)**
		findItem.setName(name);
		findItem.setPrice(price);
		findItem.setStockQuantity(stockQuantity);
	}
	
	

}
