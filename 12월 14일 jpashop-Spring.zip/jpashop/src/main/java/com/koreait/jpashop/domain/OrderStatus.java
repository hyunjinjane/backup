package com.koreait.jpashop.domain;

public enum OrderStatus {	// 3-1

	ORDER, CANCEL
	
}
