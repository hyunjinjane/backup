package com.koreait.jpashop.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.koreait.jpashop.domain.Item;
import com.koreait.jpashop.domain.Order;
import com.koreait.jpashop.domain.OrderItem;
import com.koreait.jpashop.domain.OrderStatus;
import com.koreait.jpashop.domain.QMember;
import com.koreait.jpashop.domain.QOrder;
import com.koreait.jpashop.dto.OrderSearch;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class OrderRepository {		// 17.

	private final EntityManager em;
	
	// Order 저장
	public void save(Order order) {
		em.persist(order);
	}
	
	
	
	// 3. 단건 조회(주문 취소)
	public Order findOne(Long id) {
		return em.find(Order.class, id);
	}
	
	
	// 2. 주문건 조회
	// 조회, queryDSL(QClass 세팅 해줘야함-build.gradle)
	public List<Order> findAll(OrderSearch orderSearch){
		
		JPAQueryFactory query = new JPAQueryFactory(em);
		QOrder order = QOrder.order;
		QMember member = QMember.member;
		
		return query.select(order)
					.from(order)
					.join(order.member, member)		// member : member의 알리아스
					//.where(order.orderStatus.eq(orderSearch.getOrderStatus()), member.name.like(orderSearch.getMemberName()))
					.where(statusEq(orderSearch.getOrderStatus()), nameLike(orderSearch.getMemberName()))
					.fetch()
					;
	}
	
	
	
	private BooleanExpression statusEq(OrderStatus orderStatus) {	//order.orderStatus.eq(orderSearch.getOrderStatus()를 이런 식으로 간단하게하게 메소드 만들어주기
		if(orderStatus == null) {
			return null;
		}
		
		return QOrder.order.orderStatus.eq(orderStatus);
	}
	
	
	private BooleanExpression nameLike(String memberName) {		//member.name.like(orderSearch.getMemberName())를 이런 식으로 간단하게하게 메소드 만들어주기
		if(memberName == null || memberName.equals("")) {
			return null;
		}
		
		return QMember.member.name.like(memberName);		
	}
	
	
	
	
	
	
	
}
