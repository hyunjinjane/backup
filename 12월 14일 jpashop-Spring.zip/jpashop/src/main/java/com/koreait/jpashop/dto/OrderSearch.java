package com.koreait.jpashop.dto;

import com.koreait.jpashop.domain.OrderStatus;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class OrderSearch {	// 20.
	
	private String memberName;
	private OrderStatus orderStatus;

}
