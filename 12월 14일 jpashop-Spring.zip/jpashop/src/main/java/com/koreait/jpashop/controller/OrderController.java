package com.koreait.jpashop.controller;

import java.util.List;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.koreait.jpashop.domain.Item;
import com.koreait.jpashop.domain.Member;
import com.koreait.jpashop.domain.Order;
import com.koreait.jpashop.dto.OrderSearch;
import com.koreait.jpashop.service.ItemService;
import com.koreait.jpashop.service.MemberService;
import com.koreait.jpashop.service.OrderService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class OrderController {	// 15.

	private final MemberService memberService;
	private final ItemService itemService;
	private final OrderService orderService;
	
	// 1. 상품주문
	// request : order
	// member 조회, item 조회
	// response : order/orderForm
	@GetMapping("/order")
	public String createForm(Model model) {
		
		// member 조회 - MemberService 가져오기
		List<Member> members = memberService.findMembers();
		
		// itme 조회 - ItemSerice 가져오기
		List<Item> items = itemService.findItems();
		
		model.addAttribute("members", members);
		model.addAttribute("items", items);

		return "order/orderForm";
	}
	
	
	// 1-1. 주문submit
	@PostMapping("/order")			// Orderservice 추가
	public String order(@RequestParam("memberId")	Long memberId,
						@RequestParam("itemId") 	Long itemId,
						@RequestParam("count") 		int count) {
		
		orderService.order(memberId, itemId, count);	// ->파라미터 넘기고 OrderSerivce.java영역에서 파라미터 받아오기
		return "redirect:/orders";		// orders로 보내기 바로 아래에 만들어 줌
		
	}
	
	
	// 2. 주문 내역
	@GetMapping("/orders")
	public String orderList(@ModelAttribute("orderSearch")OrderSearch orderSearch, Model model) {	// OrderSearch.java로 dto를 따로 만들어줌
		// 조회
		List<Order> orders = orderService.findOrders(orderSearch);		//-> OrderService.java
		model.addAttribute("orders", orders);
		
		return "order/orderList";
		
	}
	
	// 3. 주문 취소
	@PostMapping("/orders/{orderId}/cancel")
	public String cancelOrder(@PathVariable("orderId")Long orderId) {
		orderService.cancelOrder(orderId);			// -> OrderService.java
		
		return "redirect:/orders";
	}
	
	
	
	
}
