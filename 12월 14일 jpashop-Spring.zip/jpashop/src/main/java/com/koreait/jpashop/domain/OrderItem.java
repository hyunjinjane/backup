package com.koreait.jpashop.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
public class OrderItem {		// 4.

	@Id @GeneratedValue
	@Column(name = "order_item_id")
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "order_id")
	private Order order;
	
	@ManyToOne
	@JoinColumn(name = "item_id")
	private Item item;
	
	private int orderPrice; // 주문가격
	private int count;		// 주문수량
	
	
	// 1-1.주문submit -> 주문상품 생성
	// 생성 메서드
	public static OrderItem createOrderItem(Item item, int orderPrice, int count) {
		OrderItem orderItem = new OrderItem();
		orderItem.setItem(item);
		orderItem.setOrderPrice(orderPrice);
		orderItem.setCount(count);
		
		// 주문한 만큼 재고 조정
		item.removeStock(count);	// -> Item.java에 removeStock 비지니스 로직 만들어줌
		return orderItem;
		
		
	}
	
	// 3. 주문 취소
	public void cancel() {
		// 재고수량 원복
		getItem().addStock(count);
	}
	
	
	
}
