package com.koreait.jpaitem.embedded;

import java.time.LocalDateTime;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.TableGenerator;

import lombok.Getter;
import lombok.Setter;

@Entity
@TableGenerator(name = "MEMBER_SEQ_GENERATOR",
				table = "MY_SEQUENCES",
				pkColumnValue = "MEMBER_SEQ", allocationSize = 1)
@Getter @Setter
public class Member {		// 8.

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE,
					generator = "MEMBER_SEQ_GENERATOR")	//위에 @TableGenerator에 name이랑 동일하게 가져옴
	private Long id;
	
	@Column(name = "name", nullable = false)
	private String username;
	
	private int age;
	
//	private LocalDateTime startDate;		-> Period.java에 분리해줌 그리고 private Period period; 넣어줌
//	private LocalDateTime endDate;
	
	// 기간 period
	// @Embedded와 @Embeddable 둘중에 하나만 넣어도 된다
	// 둘다 넣어줄것을 권장
	@Embedded
	private Period period;
	
	
		
//	private String city;					-> Address.java에 분리해줌 그리고 private Address address; 넣어줌
//	private String street;
//	private String zipcode;
	
	// 주소 Address
	@Embedded
	private Address address;
	
	
	// 회사 주소
	/*
	@Embedded
	@AttributeOverrides({		// 한 엔티티에서 가져오는거라 이름이 중복되니까 이름을 재 설정해 줌
			@AttributeOverride(name = "city", column = @Column(name = "WORK_CITY")),
			@AttributeOverride(name = "street", column = @Column(name = "WORK_STREET")),
			@AttributeOverride(name = "zipcode", column = @Column(name = "WORK_ZIPCODE"))})
	private Address workAddress;
	*/
	
	
	
	
}
