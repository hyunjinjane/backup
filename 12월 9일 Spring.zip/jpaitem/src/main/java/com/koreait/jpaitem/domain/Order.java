package com.koreait.jpaitem.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

//@Entity							// 3.
@Table(name = "ORDERS")			// 클래스명인 order가 테이블명인데 그걸 ORDERS라는 이름으로 바꿔줌
@Getter @Setter
public class Order {
	
	@Id @GeneratedValue
	@Column(name = "ORDER_ID")
	private Long id;
	
	//	@Column(name = "MEMBER_ID")
	//	private Long memberId;
	@ManyToOne	// 단방향 매핑
	@JoinColumn(name = "MEMBER_ID")
	private Member member;
	
	private LocalDateTime orderDate;
	private String status;
	
	
	@OneToMany(mappedBy = "order")	// 양방향 매핑
	private List<OrderItem> orderItems = new ArrayList<OrderItem>();
	
	public void addOrderItem(OrderItem orderItem) {
		orderItem.setOrder(this);
		this.orderItems.add(orderItem);
	}

	
	
}
