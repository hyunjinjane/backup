package com.koreait.jpashop.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.koreait.jpashop.domain.Member;
import com.koreait.jpashop.repository.MemberRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MemberService {	// 9.
	
	//@Autowired  
	public final MemberRepository memberRepository;

	// 회원가입
	@Transactional	// springframework의 어노테이션 선택하기 (Transactional이 두개가 나오니까 주의!)
	public Long join(Member member) {
		memberRepository.save(member);
		return member.getId();
	}
	
	
	
	
	
	
	
	
}
