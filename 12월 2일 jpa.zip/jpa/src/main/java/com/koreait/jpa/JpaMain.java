package com.koreait.jpa;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaMain {	//1.2
	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");			// persistence.xml에 설정 파일명을 hello로 해줌
		EntityManager em = emf.createEntityManager();			// emf, em jpa를 사용하기위한 설정
		
		// transaction 방생시켜 줌 
		EntityTransaction tx = em.getTransaction();
		tx.begin(); 	// transaction 시작할꺼다
		
		try {
			// JPQL
			// JPA는 쿼리를 짤때 Table을 대상으로 쿼리를 짜지 않고, 
			// member 객체를 통해서 쿼리를 짠다
			List<Member> result = em.createQuery("select m from Member as m", Member.class)
									.setFirstResult(5)		// 5번 부터
									.setMaxResults(10)		// 10개 가지고와
									.getResultList();
			
			for(Member member : result) {
				System.out.println("member.name = " + member.getName());
			}
			
			
			
//			//회원 조회
//			Member findMember = em.find(Member.class, 2L);
//			System.out.println("==================================");
//			System.out.println("findMember.id : " + findMember.getId());
//			System.out.println("findMember.name : " + findMember.getName());
//			
//			// 회원 수정
//			findMember.setName("UpdateUser");
//			
//			// 회원 삭제
//			em.remove(findMember);
//			
//			
			/*
			// 회원 등록
			Member member = new Member();
			
			// 추가
			member.setId(3L);
			member.setName("userC");
			
			// persist : db에 저장
			em.persist(member);		// JPA에 요청을 날리는 persist
			*/
			
			tx.commit();
		}catch(Exception e) {
			tx.rollback();
		}finally {
			em.close();
			emf.close();
		}
		
		
	}
}
