package com.shinnaHotel.reservation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shinnaHotel.DAO.ReservationDAO;
import com.shinnaHotel.DTO.ReservationDTO;
import com.shinnaHotel.action.Action;
import com.shinnaHotel.action.ActionForward;

public class DoReservationAction implements Action{
	// 예약하기
	
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) {
		System.out.println("execute 도착");
		
		ActionForward forward = new ActionForward();
		ReservationDAO rdao = new ReservationDAO();
		ReservationDTO rdto = new ReservationDTO();
		
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
//		Date res_checkin = null;
//		Date res_checkout = null;
		
		try {
			rdto.setRes_checkin(transFormat.parse(req.getParameter("checkin_date")));
			rdto.setRes_checkout(transFormat.parse(req.getParameter("checkout_date")));
			rdto.setU_id(req.getParameter("u_id"));
			rdto.setRes_adults(Integer.parseInt(req.getParameter("adults")));
			rdto.setRes_kids(Integer.parseInt(req.getParameter("children")));
			rdto.setRes_rtype(req.getParameter("r_type"));
			rdto.setRes_price(Integer.parseInt(req.getParameter("r_price")));
			rdto.setR_id(Integer.parseInt(req.getParameter("r_id")));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		String u_id = req.getParameter("u_id");
//		int res_adults = Integer.parseInt(req.getParameter("adults"));
//		int res_kids = Integer.parseInt(req.getParameter("children"));
//		String r_type = req.getParameter("r_type");
//		int r_price = Integer.parseInt(req.getParameter("r_price"));
//		int r_id = Integer.parseInt(req.getParameter("r_id"));
//		
		
//		rdto.setRes_checkin(transFormat.parse(req.getParameter("checkin_date")));
//		rdto.setRes_checkout(transFormat.parse(req.getParameter("checkout_date")));
//		rdto.setU_id(req.getParameter("u_id"));
//		rdto.setRes_adults(Integer.parseInt(req.getParameter("adults")));
//		rdto.setRes_kids(Integer.parseInt(req.getParameter("children")));
//		rdto.setRes_rtype(req.getParameter("r_type"));
//		rdto.setRes_price(Integer.parseInt(req.getParameter("r_price")));
//		rdto.setR_id(Integer.parseInt(req.getParameter("r_id")));
		
		System.out.println(req.getParameter("r_type"));
		
			
		forward.setRedirect(true);
		if(rdao.insertreservation(rdto)) {
			
			forward.setPath("/reservation/reservationList.re");
		}
		
		
		return forward;
	}
	 
}
